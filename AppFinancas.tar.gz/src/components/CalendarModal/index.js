import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableWithoutFeedback,
    TouchableOpacity,
} from 'react-native';

import { Calendar, LocaleConfig } from 'react-native-calendars';
import { ptBR } from './localeCalendar'

LocaleConfig.locales['pt-br'] = ptBR;
LocaleConfig.defaultLocale = 'pt-br';

export default function CalendarModal({ setVisible, handleFilter }) {
    const [dateNow, setDateNow] = useState(new Date())
    const [markedDates, setMarkedDates] = useState({})

    function handleOnDayPress(date) {
        setDateNow(new Date(date.dateString))

        let markedDay = {}

        markedDay[date.dateString] = {
            selected: true,
            selectedColor: '#191e29',
            textColor: '#fff'
        }

        setMarkedDates(markedDay)
    }

    function handleFilterDate() {
        handleFilter(dateNow)
        setVisible()
    }

    return (
        <View style={styles.container}>
            <TouchableWithoutFeedback onPress={setVisible}>
                <View style={{ flex: 1 }}></View>
            </TouchableWithoutFeedback>

            <View style={styles.modalContent}>
                <Calendar
                    onDayPress={handleOnDayPress}
                    markedDates={markedDates}
                    enableSwipeMonths={true}
                    theme={{
                        todayTextColor: '#20b13fff',
                        selectedDayBackgroundColor: '#191e29',
                        selectedDayTextColor: '#fff'
                    }}
                />

                <TouchableOpacity style={styles.buttonFilter} onPress={handleFilterDate}>
                    <Text style={styles.buttonFilterText}>Filtrar</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'rgba(34,34,34, 0.4)',
    },
    modalContent: {
        flex: 2,
        justifyContent: 'center',
        backgroundColor: '#fff',
        padding: 14,
    },
    buttonFilter: {
        borderRadius: 4,
        backgroundColor: '#191e29',
        height: 45,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 20,
    },
    buttonFilterText: {
        color: '#fff',
        fontSize: 19,
        fontWeight: 'bold',
    }
})
