import React, { useState } from "react";
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity
} from 'react-native'

import { Feather } from "@expo/vector-icons";

export default function RegisterTypes({ type, sendTypeChanged }) {
    const [typeChecked, setTypeChecked] = useState(type)

    function changeType(name) {
        if (name === 'receita') {
            setTypeChecked('receita')
            sendTypeChanged('receita')
        } else {
            setTypeChecked('despesa')
            sendTypeChanged('despesa')
        }
    }

    return (
        <View style={styles.registerContainer}>
            <TouchableOpacity
                style={[
                    styles.registerTypeButton,
                    typeChecked === 'receita' && {
                        backgroundColor: '#f5f5f5',
                        borderWidth: 1.5,
                        borderColor: '#6264d6ff'
                    },
                    typeChecked !== 'receita' && {
                        backgroundColor: '#ffffff',
                        borderWidth: 0
                    }
                ]}
                onPress={() => changeType('receita')}
            >
                <Feather name="arrow-up" size={25} color="#121212" />
                <Text style={styles.registerLabel}>
                    Receita
                </Text>
            </TouchableOpacity>

            <TouchableOpacity
                style={[
                    styles.registerTypeButton,
                    typeChecked === 'despesa' && {
                        backgroundColor: '#f5f5f5',
                        borderWidth: 1.5,
                        borderColor: '#6264d6ff'
                    },
                    typeChecked !== 'despesa' && {
                        backgroundColor: '#ffffff',
                        borderWidth: 0
                    }
                ]}
                onPress={() => changeType('despesa')}
            >
                <Feather name="arrow-down" size={25} color="#121212" />
                <Text style={styles.registerLabel}>
                    Despesa
                </Text>
            </TouchableOpacity>
        </View>
    )
}

const styles = StyleSheet.create({
    registerContainer: {
        flexDirection: 'row',
        width: '100%',
        paddingLeft: '5%',
        paddingRight: '5%',
        justifyContent: 'space-between',
        alignItems: 'center'
    },
    registerTypeButton: {
        width: '47%',
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        height: 45,
        borderRadius: 4,
        marginBottom: 14,

    },
    registerLabel: {
        marginLeft: 8,
        fontSize: 17,
    }
})
