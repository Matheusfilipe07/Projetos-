import React, { useMemo } from "react";
import { View, Text, StyleSheet } from 'react-native';

export default function BalanceItem({ data }) {

    const labelName = useMemo(() => {
        if (data.tag === 'saldo') {
            return {
                label: 'Saldo atual',
                color: '#191e29'
            }
        } else if (data.tag === 'receita') {
            return {
                label: 'Entradas de hoje',
                color: '#20b13fff'
            }
        } else {
            return {
                label: 'Saídas de hoje',
                color: '#DB162F'
            }
        }

    }, [data])

    return (
        <View style={[styles.container, { backgroundColor: labelName.color }]}>
            <Text style={styles.label}>{labelName.label}</Text>
            <Text style={styles.balance}>R${Number(data.saldo).toFixed(2).replace('.', ',')}</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        marginLeft: 2,
        marginRight: 2,
        borderRadius: 8,
        justifyContent: 'center',
        alignItems: 'flex-start',
        width: 300,
        height: 180,
        paddingLeft: 14,
        overflow: 'hidden',

        //sombra IOS
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,

        //sombra android
        elevation: 8
    },
    label: {
        color: '#fff',
        fontSize: 19,
        fontWeight: 'bold'
    },
    balance: {
        marginTop: 5,
        color: '#fff',
        fontSize: 30,
    },
});
