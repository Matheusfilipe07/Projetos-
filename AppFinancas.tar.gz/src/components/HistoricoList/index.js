import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    Alert,
    TouchableWithoutFeedback,
} from 'react-native';

import Icon from '@expo/vector-icons/Feather'

export default function HistoricoList({ data, deleteItem}) {
    function handleDeleteItem(){
        Alert.alert(
            'Atenção',
            'Você tem certeza que deseja deletar esse registro?',
            [{
                text:'Cancelar',
                style: 'cancel',
            },
            {
                text: 'Continuar',
                onPress: () => deleteItem(data.id)
            }
        ]
        )
    }

    return (
        <TouchableWithoutFeedback onLongPress={handleDeleteItem}>
            <View style={styles.container}>

                <View style={styles.tipo}>
                    <View style={[
                        styles.iconView,
                        { backgroundColor: data.type === 'despesa' ? '#DB162F' : '#20b13fff' }
                    ]}>
                        <Icon
                            name={data.type === 'despesa' ? 'arrow-down' : 'arrow-up'}
                            size={20}
                            color="#fff" />
                        <Text style={styles.tipoText}>{data.type}</Text>
                    </View>
                </View>

                <Text style={styles.valorText}>
                    R$ {Number(data.value).toFixed(2).replace('.', ',')}
                </Text>
            </View>
        </TouchableWithoutFeedback>

    )
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#f0f3ff',
        borderRadius: 4,
        marginBottom: 14,
        marginLeft: 10,
        marginRight: 10,
        padding: 12

    },
    tipo: {
        flexDirection: 'row',
    },
    iconView: {
        flexDirection: 'row',
        paddingBottom: 4,
        paddingTop: 4,
        paddingLeft: 8,
        paddingRight: 8,
        borderRadius: 4,
        marginBottom: 5
    },
    tipoText: {
        color: '#fff',
        fontSize: 16,
        fontStyle: 'italic'
    },
    valorText: {
        color: '#121212',
        fontSize: 22
    }
})