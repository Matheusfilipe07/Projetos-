import React, { useState, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TextInput,
  KeyboardAvoidingView,
  TouchableOpacity,
  Platform,
  ActivityIndicator
}
  from "react-native";

import { useNavigation } from "@react-navigation/native";

import { AuthContext } from "../../contexts/auth";

export default function SignIn() {
  const navigation = useNavigation();
  const { signIn, loadingAuth } = useContext(AuthContext);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  function handleLogin() {
    signIn(email, password);
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      enabled
      style={styles.background}>

      <View style={styles.container}>
        <Image
          source={require("../../assets/Logo.png")}
          style={styles.logo}
        />

        <View style={styles.AreaInput}>
          <TextInput
            placeholder="Digite seu e-mail"
            style={styles.input}
            value={email}
            onChangeText={text => setEmail(text)}
          />
        </View>
        <View style={styles.AreaInput}>
          <TextInput
            placeholder="Digite sua senha"
            style={styles.input}
            secureTextEntry={true}
            value={password}
            onChangeText={text => setPassword(text)}
          />
        </View>

        <TouchableOpacity style={styles.submitButton} activeOpacity={0.8} onPress={handleLogin}>
          {loadingAuth ? (
            <ActivityIndicator size={20} color="#fff" />
          ) : (
            <Text style={styles.submitText}>Acessar</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity style={styles.link} onPress={() => navigation.navigate("SignUp")}>
          <Text style={styles.linkText}>Criar uma conta!</Text>
        </TouchableOpacity>

      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor: "#f0f4ff",
  },
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  logo: {
    marginBottom: 25,
  },
  AreaInput: {
    flexDirection: "row",
  },
  input: {
    backgroundColor: "#fff",
    width: '90%',
    fontSize: 17,
    padding: 10,
    borderRadius: 8,
    color: "#121212",
    marginBottom: 15,
  },
  submitButton: {
    backgroundColor: "#191e29",
    width: '90%',
    height: 45,
    marginTop: 10,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  submitText: {
    color: "#fff",
    fontSize: 20,
  },
  link: {
    marginTop: 15,
    marginBottom: 20,
  },
  linkText: {
    color: "#171717",
    fontSize: 16,
    fontWeight: 500,
  },

});