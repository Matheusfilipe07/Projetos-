import React, { useContext } from 'react';
import {
    View,
    Text,
    StyleSheet,
    SafeAreaView,
    TouchableOpacity,
} from 'react-native';

import Header from '../../components/Header'

import { AuthContext } from '../../contexts/auth'
import { useNavigation } from '@react-navigation/native';

export default function Profile() {
    const {user, signOut} = useContext(AuthContext)
    const navigation = useNavigation()

    return (
        <SafeAreaView style={styles.container}>
            <Header title="Meu perfil" />

            <Text style={styles.message}>
                Hey, bem-vindo de volta!
            </Text>

            <Text numberOfLines={1} style={styles.name}>
                {user && user.name}
            </Text>

            <TouchableOpacity style={styles.newLink} onPress={ () => navigation.navigate('Registrar')}>
                <Text style={styles.newText}>Fazer registro</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.logout} onPress={ () => signOut() }>
                <Text style={styles.logoutText}>Sair</Text>
            </TouchableOpacity>


        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f0f4ff',
        alignItems: 'center'
    },
    message: {
        fontSize: 18,
        fontWeight: 'bold',
        marginTop: 24,
        marginTop: 80
    },
    name: {
        fontSize: 24,
        marginBottom: 24,
        marginTop: 8,
        paddingVertical: 0,
        paddingHorizontal: 14,
        color: '#121212',
    },
    newLink: {
        backgroundColor: '#191e29',
        width: '90%',
        height: 45,
        borderRadius: 8,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 14,

    },
    newText: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#fff',
    },
    logout: {
        justifyContent: 'center',
        alignItems: 'center',
        width: '90%',
        height: 45,
        borderWidth: 1,
        borderRadius: 8,
        borderColor: '#DB162F',
    },
    logoutText: {
        color: '#DB162F',
        fontSize: 18,
        fontWeight: 'bold',
    }
})