import React, { useContext, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
  TouchableOpacity,
  Platform,
  ActivityIndicator
} from "react-native";

import { AuthContext } from "../../contexts/auth";

export default function SignUp() {

  const { signUp, loadingAuth } = useContext(AuthContext);
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState(''); 

  function handleSignUp() {
    if(nome === '' || email === '' || senha === '') {
      alert("Preencha todos os campos!");
      return;
    }
    signUp(email, senha, nome);
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      enabled
      style={styles.background}>

      <View style={styles.container}>
        <View style={styles.AreaInput}>
          <TextInput
            placeholder="Nome"
            style={styles.input}
            value={nome}
            onChangeText={(text) => setNome(text)}
          />
        </View>

        <View style={styles.AreaInput}>
          <TextInput
            placeholder="E-mail"
            style={styles.input}
            value={email}
            onChangeText={(text) => setEmail(text)}
          />
        </View>

        <View style={styles.AreaInput}>
          <TextInput
            placeholder="Senha"
            style={styles.input}
            secureTextEntry={true}
            value={senha}
            onChangeText={(text) => setSenha(text)}
          />
        </View>

        <TouchableOpacity style={styles.submitButton} activeOpacity={0.8} onPress={handleSignUp}>
          {loadingAuth ? (
            <ActivityIndicator size={20} color="#fff" />
          ) : (
            <Text style={styles.submitText}>Cadastrar</Text>
          )
          }
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor: "#f0f4ff",
  },
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  AreaInput: {
    flexDirection: "row",
  },
  input: {
    backgroundColor: "#fff",
    width: '90%',
    fontSize: 17,
    padding: 10,
    borderRadius: 8,
    color: "#121212",
    marginBottom: 15,
  },
  submitButton: {
    backgroundColor: "#191e29",
    width: '90%',
    height: 45,
    marginTop: 10,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  submitText: {
    color: "#fff",
    fontSize: 20,
  },
});