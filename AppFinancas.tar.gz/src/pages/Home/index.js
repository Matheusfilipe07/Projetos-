import React, { useContext, useEffect, useState } from "react";
import {
  View,
  Text,
  SafeAreaView,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal
} from "react-native";

import { AuthContext } from "../../contexts/auth";
import Header from "../../components/Header";
import api from "../../services/api";

import { format } from 'date-fns';

import { useIsFocused } from "@react-navigation/native";

import BalanceItem from "../../components/BalanceItem";
import { Feather } from '@expo/vector-icons';
import HistoricoList from '../../components/HistoricoList'
import CalendarModal from "../../components/CalendarModal";

export default function Home() {
  const isFocused = useIsFocused();
  const [listBalance, setListBalance] = useState([]);
  const [moviments, setMoviments] = useState([])
  const [modalVisible, setModalVisible] = useState(false)

  const [dateMovements, setDateMovements] = useState(new Date());

  useEffect(() => {
    let isActive = true;

    async function getMovements() {
      let date = new Date(dateMovements)
      let onlyDate = date.valueOf() + date.getTimezoneOffset() * 60 * 1000
      let dateFormated = format(onlyDate, 'dd/MM/yyyy')

      const receives = await api.get('/receives', {
        params: {
          date: dateFormated,
        }
      })

      const balance = await api.get('/balance', {
        params: {
          date: dateFormated
        }
      })

      if (isActive) {
        setMoviments(receives.data)
        setListBalance(balance.data)
      }
    }

    getMovements();

    return () => isActive = false
  }, [isFocused, dateMovements]);

  async function handleDelete(id) {
    try {
      await api.delete('/receives/delete', {
        params: {
          item_id: id
        }
      })

      setDateMovements(new Date())
    } catch (err) {
      console.log(err)
    }
  }

  function filterDateMovements(dateSelected) {
    setDateMovements(dateSelected)
  }

  return (
    <SafeAreaView style={styles.background}>
      <Header title="Minhas movimentações" />
      <FlatList
        style={styles.listBalance}
        data={listBalance}
        horizontal={true}
        showsHorizontalScrollIndicator={false}
        keyExtractor={item => item.tag}
        renderItem={({ item }) => <BalanceItem data={item} />}
        ItemSeparatorComponent={() => <View style={{ width: 14 }} />}
      />

      <View style={styles.area}>
        <TouchableOpacity onPress={() => setModalVisible(true)} >
          <Feather name="calendar" color="#121212" size={30} />
        </TouchableOpacity>
        <Text style={styles.title}>Ultimas movimentações</Text>
      </View>

      <FlatList
        style={styles.lista}
        data={moviments}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <HistoricoList data={item} deleteItem={handleDelete} />}
        ListEmptyComponent={() => (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>Nenhuma movimentação encontrada.</Text>
          </View>
        )}

        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 5 }}
      />

      <Modal visible={modalVisible} animation="fade" transparent={true}>
        <CalendarModal
          setVisible={() => setModalVisible(false)}
          handleFilter={filterDateMovements}
        />
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor: '#f0f4ff',
    paddingTop: 20,
    padding: 10,
  },
  listBalance: {
    height: 0,
    marginBottom: 0,
  },

  area: {
    marginTop: -300,
    backgroundColor: '#fff',
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    flexDirection: 'row',
    paddingLeft: 14,
    paddingRight: 14,
    paddingTop: 10,
    alignItems: 'baseline',
  },
  title: {
    marginLeft: 4,
    color: '#121212',
    marginBottom: 14,
    fontWeight: 'bold',
    fontSize: 18,
  },
  lista: {
    flex: 1,
    backgroundColor: '#fff',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 100, // Ajusta a distância se necessário
  },
  emptyText: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
    fontSize: 16,
    color: '#999',
  },

});
