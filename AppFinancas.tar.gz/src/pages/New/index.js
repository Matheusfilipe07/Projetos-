import React, {useState} from "react";
import {
    View,
    Text,
    StyleSheet,
    SafeAreaView,
    TextInput,
    TouchableOpacity,
    TouchableWithoutFeedback,
    Keyboard,
    Alert

} from 'react-native';

import Header from '../../components/Header'
import RegisterTypes from "../../components/RegisterTypes";

import api from '../../services/api'
import { format } from "date-fns";
import { useNavigation } from "@react-navigation/native";

export default function New() {
    const navigation = useNavigation()

    const [labelInput, setLabelInput] = useState('')
    const [valueInput, setValueInput] =useState('')
    const [type, setType]= useState('receita')

    function handleRegister(){
        Keyboard.dismiss()

        if(isNaN(parseFloat(valueInput)) || type === null){
            alert('Preencha todos os campos')
            return;
        }

        Alert.alert(
            'Confirmando dados',
            `Tipo: ${type} - Valor: R$ ${parseFloat(valueInput.replace(',', '.')).toFixed(2).replace('.', ',')}`,

            [
                {
                    text: 'Cancelar',
                    style: 'cancel'
                },
                {
                    text: 'Continuar',
                    onPress: () => handleAdd()
                }
            ]
        )

    }

    async function handleAdd(){
        Keyboard.dismiss()
        
        await api.post('/receive',{
            description:  labelInput,
            value: Number(valueInput.replace(',', '.')),
            type: type,
            date: format(new Date(),'dd/MM/yyyy')
        })

        setLabelInput('')
        setValueInput('')
        navigation.navigate('Home')
    }


    return (
        <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
        <View style={styles.background}>
            <Header title="Registrando" />

            <SafeAreaView style={{marginTop: 18, alignItems: 'center'}}>
                <TextInput
                    style={styles.input}
                    placeholder="Descrição desse registro"
                    value={labelInput}
                    onChangeText={(text) => setLabelInput(text)}
                />
                <TextInput
                    style={styles.input}
                    placeholder="Valor desejado"
                    keyboardType="numeric"
                    value={valueInput}
                    onChangeText={(text) => setValueInput(text)}
                />

                <RegisterTypes type={type} sendTypeChanged={ (item) => setType(item) } />


                <TouchableOpacity
                 style={styles.btnRegistrar}
                 onPress={handleRegister}
                 >
                    <Text style={styles.registrar}>Registrar</Text>
                </TouchableOpacity>

            </SafeAreaView>
        </View>
        </TouchableWithoutFeedback>
    )
}

const styles = StyleSheet.create({
    background: {
        flex: 1,
        marginTop: 20,
        backgroundColor: '#f0f4ff'
    },
    input:{
        height: 50,
        width: '90%',
        backgroundColor: '#fff',
        fontSize: 17,
        paddingVertical: 0,
        paddingHorizontal: 8,
        marginBottom: 14,
        borderRadius: 6
    },
    btnRegistrar:{
        width: '90%',
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#1db985ff',
        borderRadius: 6,
    },
    registrar:{
        color: '#fff',
        fontSize: 19,
        fontWeight: 'bold',
    }
})